using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public class Student : Person
{
    [Display(Name = "Группа")]
    public int GroupId { get; set; }

    public Group? Group { get; set; }

    public ICollection<Grade> Grades { get; set; } = new List<Grade>();

    public ICollection<Attendance> AttendanceRecords { get; set; } = new List<Attendance>();
}
