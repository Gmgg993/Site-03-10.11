using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

/// <summary>Запись посещаемости студента за конкретный день.</summary>
public class Attendance
{
    public int Id { get; set; }

    [Display(Name = "Студент")]
    public int StudentId { get; set; }

    public Student? Student { get; set; }

    [Display(Name = "Дата")]
    public DateTime Date { get; set; } = DateTime.Today;

    [Display(Name = "Присутствовал")]
    public bool Present { get; set; }
}
