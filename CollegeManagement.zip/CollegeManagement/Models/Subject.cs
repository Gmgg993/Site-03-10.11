using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public class Subject
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Введите название предмета")]
    [Display(Name = "Предмет")]
    public string Title { get; set; } = "";

    [Range(1, 1000, ErrorMessage = "Количество часов должно быть от 1 до 1000")]
    [Display(Name = "Часы")]
    public int Hours { get; set; } = 72;

    public int? TeacherId { get; set; }

    public Teacher? Teacher { get; set; }

    public ICollection<Grade> Grades { get; set; } = new List<Grade>();
}
