using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public class Grade
{
    public int Id { get; set; }

    [Display(Name = "Студент")]
    public int StudentId { get; set; }

    public Student? Student { get; set; }

    [Display(Name = "Предмет")]
    public int SubjectId { get; set; }

    public Subject? Subject { get; set; }

    [Range(2, 5, ErrorMessage = "Оценка должна быть от 2 до 5")]
    [Display(Name = "Оценка")]
    public int Value { get; set; } = 5;

    [Display(Name = "Дата")]
    public DateTime Date { get; set; } = DateTime.Today;
}
