using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public class Group
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Введите название группы")]
    [Display(Name = "Название группы")]
    public string Name { get; set; } = "";

    [Range(1, 4, ErrorMessage = "Курс должен быть от 1 до 4")]
    [Display(Name = "Курс")]
    public int Course { get; set; } = 1;

    public ICollection<Student> Students { get; set; } = new List<Student>();
}
