using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public class Teacher : Person
{
    [Range(0, 55, ErrorMessage = "Стаж должен быть от 0 до 55 лет")]
    [Display(Name = "Стаж")]
    public int Experience { get; set; }

    public ICollection<Subject> Subjects { get; set; } = new List<Subject>();

    public string SubjectTitles => string.Join(", ", Subjects.Select(s => s.Title));
}
