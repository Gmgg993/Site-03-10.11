using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

/// <summary>
/// Базовый класс для людей колледжа (студенты, преподаватели).
/// Отдельной таблицы в БД нет: поля попадают в таблицы наследников.
/// </summary>
public abstract class Person
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Введите имя")]
    [Display(Name = "Имя")]
    public string Name { get; set; } = "";

    [Required(ErrorMessage = "Введите фамилию")]
    [Display(Name = "Фамилия")]
    public string Surname { get; set; } = "";

    [Range(15, 70, ErrorMessage = "Возраст должен быть от 15 до 70")]
    [Display(Name = "Возраст")]
    public int Age { get; set; } = 18;

    public string FullName => $"{Name} {Surname}";

    public override string ToString() => FullName;
}
