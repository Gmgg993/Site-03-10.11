using CollegeManagement.Models;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CollegeManagement.Controllers;

public class StudentController : Controller
{
    private readonly StudentService _students;

    public StudentController(StudentService students) => _students = students;

    public IActionResult Index(string? search)
    {
        ViewData["Search"] = search;
        var list = string.IsNullOrWhiteSpace(search) ? _students.GetAll() : _students.Search(search);
        return View(list);
    }

    [HttpGet]
    public IActionResult Create()
    {
        LoadGroups();
        return View(new Student());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Create([Bind("Name,Surname,Age,GroupId")] Student student)
    {
        if (ModelState.IsValid)
        {
            try
            {
                _students.Add(student);
                return RedirectToAction(nameof(Index));
            }
            catch (ArgumentException ex)
            {
                ModelState.AddModelError("", ex.Message);
            }
        }

        LoadGroups();
        return View(student);
    }

    private void LoadGroups() =>
        ViewBag.Groups = new SelectList(_students.GetGroups(), nameof(Group.Id), nameof(Group.Name));
}
