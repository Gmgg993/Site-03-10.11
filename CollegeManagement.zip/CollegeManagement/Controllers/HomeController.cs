using System.Security.Claims;
using CollegeManagement.Data;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

public class HomeController : Controller
{
    private readonly CollegeDbContext _db;
    private readonly ReportManager _reports;

    public HomeController(CollegeDbContext db, ReportManager reports)
    {
        _db = db;
        _reports = reports;
    }

    public IActionResult Index() => View(_reports.GetStatistics());

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        ViewData["ReturnUrl"] = returnUrl;
        return View();
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(string login, string password, string? returnUrl = null)
    {
        var account = _db.Users.FirstOrDefault(u => u.Login == login);

        if (account == null || !account.VerifyPassword(password ?? ""))
        {
            ViewData["ReturnUrl"] = returnUrl;
            ViewData["Error"] = "Неверный логин или пароль";
            return View();
        }

        var claims = new List<Claim>
        {
            new(ClaimTypes.Name, account.Login),
            new(ClaimTypes.Role, account.Role)
        };
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            return Redirect(returnUrl);

        return RedirectToAction(nameof(Admin));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction(nameof(Index));
    }

    [Authorize]
    public IActionResult Admin() => View(_reports.GetStatistics());
}
