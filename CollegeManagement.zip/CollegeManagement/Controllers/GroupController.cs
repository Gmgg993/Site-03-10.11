using CollegeManagement.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class GroupController : Controller
{
    private readonly CollegeDbContext _db;

    public GroupController(CollegeDbContext db) => _db = db;

    public IActionResult Index() =>
        View(_db.Groups.Include(g => g.Students).OrderBy(g => g.Id).ToList());
}
