using CollegeManagement.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class TeacherController : Controller
{
    private readonly CollegeDbContext _db;

    public TeacherController(CollegeDbContext db) => _db = db;

    public IActionResult Index() =>
        View(_db.Teachers.Include(t => t.Subjects).OrderBy(t => t.Id).ToList());
}
