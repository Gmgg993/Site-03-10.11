using CollegeManagement.Models;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CollegeManagement.Controllers;

public class AttendanceController : Controller
{
    private readonly AttendanceManager _attendance;
    private readonly StudentService _students;

    public AttendanceController(AttendanceManager attendance, StudentService students)
    {
        _attendance = attendance;
        _students = students;
    }

    public IActionResult Index()
    {
        ViewBag.Percent = _attendance.GetPercent();
        return View(_attendance.GetAll());
    }

    [HttpGet]
    public IActionResult Mark()
    {
        LoadStudents();
        return View();
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Mark(int studentId, bool present, DateTime? date)
    {
        try
        {
            _attendance.Mark(studentId, present, date);
            return RedirectToAction(nameof(Index));
        }
        catch (ArgumentException ex)
        {
            ModelState.AddModelError("", ex.Message);
            LoadStudents();
            return View();
        }
    }

    private void LoadStudents() =>
        ViewBag.Students = new SelectList(_students.GetAll(), nameof(Student.Id), nameof(Student.FullName));
}
