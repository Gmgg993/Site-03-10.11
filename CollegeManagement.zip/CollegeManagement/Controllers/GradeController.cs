using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class GradeController : Controller
{
    private readonly CollegeDbContext _db;

    public GradeController(CollegeDbContext db) => _db = db;

    public IActionResult Index()
    {
        var grades = _db.Grades
            .Include(g => g.Student)
            .Include(g => g.Subject)
            .OrderBy(g => g.Id)
            .ToList();

        ViewBag.Average = grades.Count == 0 ? 0 : grades.Average(g => g.Value);
        return View(grades);
    }

    [HttpGet]
    public IActionResult Create()
    {
        LoadLists();
        return View(new Grade());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Create([Bind("StudentId,SubjectId,Value")] Grade grade)
    {
        if (!_db.Students.Any(s => s.Id == grade.StudentId))
            ModelState.AddModelError(nameof(Grade.StudentId), "Выберите студента");
        if (!_db.Subjects.Any(s => s.Id == grade.SubjectId))
            ModelState.AddModelError(nameof(Grade.SubjectId), "Выберите предмет");

        if (!ModelState.IsValid)
        {
            LoadLists();
            return View(grade);
        }

        grade.Date = DateTime.Today;
        _db.Grades.Add(grade);
        _db.SaveChanges();
        return RedirectToAction(nameof(Index));
    }

    private void LoadLists()
    {
        ViewBag.Students = new SelectList(_db.Students.OrderBy(s => s.Id).ToList(), nameof(Student.Id), nameof(Student.FullName));
        ViewBag.Subjects = new SelectList(_db.Subjects.OrderBy(s => s.Id).ToList(), nameof(Subject.Id), nameof(Subject.Title));
    }
}
