using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Services;

public class AttendanceManager
{
    private readonly CollegeDbContext _db;

    public AttendanceManager(CollegeDbContext db) => _db = db;

    public List<Attendance> GetAll() =>
        _db.Attendances
            .Include(a => a.Student)
            .OrderByDescending(a => a.Date)
            .ThenBy(a => a.Id)
            .ToList();

    /// <summary>Отмечает студента. Если за этот день отметка уже есть — обновляет её.</summary>
    public Attendance Mark(int studentId, bool present, DateTime? date = null)
    {
        if (!_db.Students.Any(s => s.Id == studentId))
            throw new ArgumentException("Студент с таким ID не найден.");

        var day = (date ?? DateTime.Today).Date;
        var record = _db.Attendances.FirstOrDefault(a => a.StudentId == studentId && a.Date == day);

        if (record == null)
        {
            record = new Attendance { StudentId = studentId, Date = day, Present = present };
            _db.Attendances.Add(record);
        }
        else
        {
            record.Present = present;
        }

        _db.SaveChanges();
        return record;
    }

    public bool Update(int attendanceId, bool present)
    {
        var record = _db.Attendances.Find(attendanceId);
        if (record == null) return false;

        record.Present = present;
        _db.SaveChanges();
        return true;
    }

    /// <summary>Общий процент посещаемости по всем отметкам.</summary>
    public double GetPercent()
    {
        var total = _db.Attendances.Count();
        if (total == 0) return 0;

        var present = _db.Attendances.Count(a => a.Present);
        return present * 100.0 / total;
    }

    public double GetPercentForStudent(int studentId)
    {
        var total = _db.Attendances.Count(a => a.StudentId == studentId);
        if (total == 0) return 0;

        var present = _db.Attendances.Count(a => a.StudentId == studentId && a.Present);
        return present * 100.0 / total;
    }
}
