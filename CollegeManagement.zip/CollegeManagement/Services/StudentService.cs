using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Services;

public class StudentService
{
    private readonly CollegeDbContext _db;

    public StudentService(CollegeDbContext db) => _db = db;

    public List<Student> GetAll() =>
        _db.Students.Include(s => s.Group).OrderBy(s => s.Id).ToList();

    public Student? GetById(int id) =>
        _db.Students.Include(s => s.Group).FirstOrDefault(s => s.Id == id);

    public List<Group> GetGroups() =>
        _db.Groups.OrderBy(g => g.Id).ToList();

    public Group? FindGroup(string name)
    {
        var wanted = name.Trim();
        // Сравнение в памяти: SQLite не умеет регистронезависимо сравнивать кириллицу.
        return _db.Groups.ToList()
            .FirstOrDefault(g => string.Equals(g.Name, wanted, StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>Поиск по имени, фамилии или названию группы (без учёта регистра).</summary>
    public List<Student> Search(string query)
    {
        var q = query.Trim();
        return GetAll()
            .Where(s => Contains(s.FullName, q) || Contains(s.Group?.Name, q))
            .ToList();
    }

    public Student Add(Student student)
    {
        student.Name = student.Name?.Trim() ?? "";
        student.Surname = student.Surname?.Trim() ?? "";

        if (student.Name.Length == 0 || student.Surname.Length == 0)
            throw new ArgumentException("Имя и фамилия не должны быть пустыми.");
        if (student.Age < 15 || student.Age > 70)
            throw new ArgumentException("Возраст должен быть от 15 до 70.");
        if (!_db.Groups.Any(g => g.Id == student.GroupId))
            throw new ArgumentException("Выберите существующую группу.");

        student.Group = null; // связь задаётся только через GroupId
        _db.Students.Add(student);
        _db.SaveChanges();
        return student;
    }

    public Student Add(string name, string surname, int age, string groupName)
    {
        var group = FindGroup(groupName);
        if (group == null)
        {
            var available = string.Join(", ", GetGroups().Select(g => g.Name));
            throw new ArgumentException($"Группа «{groupName}» не найдена. Доступные группы: {available}.");
        }

        return Add(new Student { Name = name, Surname = surname, Age = age, GroupId = group.Id });
    }

    private static bool Contains(string? value, string query) =>
        value != null && value.Contains(query, StringComparison.OrdinalIgnoreCase);
}
