using CollegeManagement.Data;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Services;

public record GroupReport(string GroupName, int Course, int StudentCount, double AverageGrade);

public record CollegeStatistics(
    int StudentCount,
    int TeacherCount,
    int GroupCount,
    int GradeCount,
    double AverageGrade,
    double AttendancePercent,
    IReadOnlyList<GroupReport> Groups);

public class ReportManager
{
    private readonly CollegeDbContext _db;
    private readonly AttendanceManager _attendance;

    public ReportManager(CollegeDbContext db, AttendanceManager attendance)
    {
        _db = db;
        _attendance = attendance;
    }

    public CollegeStatistics GetStatistics()
    {
        var grades = _db.Grades.ToList();
        var groups = _db.Groups.Include(g => g.Students).OrderBy(g => g.Id).ToList();

        var groupReports = groups.Select(g =>
        {
            var studentIds = g.Students.Select(s => s.Id).ToHashSet();
            var values = grades.Where(x => studentIds.Contains(x.StudentId)).Select(x => x.Value).ToList();
            return new GroupReport(g.Name, g.Course, g.Students.Count, values.Count == 0 ? 0 : values.Average());
        }).ToList();

        return new CollegeStatistics(
            StudentCount: _db.Students.Count(),
            TeacherCount: _db.Teachers.Count(),
            GroupCount: groups.Count,
            GradeCount: grades.Count,
            AverageGrade: grades.Count == 0 ? 0 : grades.Average(g => g.Value),
            AttendancePercent: _attendance.GetPercent(),
            Groups: groupReports);
    }

    public string GenerateReport() => "Отчёт колледжа сформирован.";
}
