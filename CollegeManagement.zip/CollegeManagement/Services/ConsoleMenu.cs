using System.Globalization;
using System.Text;
using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Services;

/// <summary>Консольное меню управления колледжем (режим по умолчанию).</summary>
public class ConsoleMenu
{
    private const int Width = 30;

    private readonly StudentService _students;
    private readonly ReportManager _reports;
    private readonly AttendanceManager _attendance;
    private readonly CollegeDbContext _db;

    public ConsoleMenu(StudentService students, ReportManager reports, AttendanceManager attendance, CollegeDbContext db)
    {
        _students = students;
        _reports = reports;
        _attendance = attendance;
        _db = db;
    }

    public void Run()
    {
        try
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;
        }
        catch (IOException) { }

        try
        {
            while (true)
            {
                ShowMenu();
                var choice = ReadLine().Trim();
                Console.WriteLine();

                try
                {
                    switch (choice)
                    {
                        case "1": AddStudent(); break;
                        case "2": ShowStudents(); break;
                        case "3": FindStudent(); break;
                        case "4": ShowTeachers(); break;
                        case "5": ShowGroups(); break;
                        case "6": AddGrade(); break;
                        case "7": ShowGrades(); break;
                        case "8": MarkAttendance(); break;
                        case "9": ShowAttendance(); break;
                        case "10": ShowStatistics(); break;
                        case "0":
                            Console.WriteLine("До свидания!");
                            return;
                        default:
                            Console.WriteLine("Неверный пункт меню.");
                            break;
                    }
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"Ошибка: {ex.Message}");
                }

                Pause();
            }
        }
        catch (EndOfStreamException)
        {
            // Ввод закрыт (Ctrl+Z / Ctrl+D) — выходим из программы.
            Console.WriteLine();
        }
    }

    // ---------- меню ----------

    private static void ShowMenu()
    {
        Clear();
        const string title = "УПРАВЛЕНИЕ КОЛЛЕДЖЕМ";
        var line = new string('=', Width);

        Console.WriteLine(line);
        Console.WriteLine(new string(' ', (Width - title.Length) / 2) + title);
        Console.WriteLine(line);
        Console.WriteLine(" ");
        Console.WriteLine("1. Добавить студента");
        Console.WriteLine("2. Показать всех студентов");
        Console.WriteLine("3. Найти студента");
        Console.WriteLine("4. Показать преподавателей");
        Console.WriteLine("5. Показать группы");
        Console.WriteLine("6. Выставить оценку");
        Console.WriteLine("7. Показать оценки");
        Console.WriteLine("8. Отметить посещаемость");
        Console.WriteLine("9. Показать посещаемость");
        Console.WriteLine("10. Статистика колледжа");
        Console.WriteLine("0. Выход");
        Console.WriteLine();
        Console.Write("Выберите действие: ");
    }

    // ---------- студенты ----------

    private void AddStudent()
    {
        var name = ReadText("Имя: ");
        var surname = ReadText("Фамилия: ");
        var age = ReadInt("Возраст: ", 15, 70);
        var group = ReadText("Группа: ");

        _students.Add(name, surname, age, group);

        Console.WriteLine();
        Console.WriteLine("Студент успешно добавлен!");
    }

    private void ShowStudents()
    {
        var list = _students.GetAll();
        if (list.Count == 0)
        {
            Console.WriteLine("Студентов пока нет.");
            return;
        }

        PrintStudents(list);
        Console.WriteLine();
        Console.WriteLine($"Всего студентов: {list.Count}");
    }

    private void FindStudent()
    {
        var query = ReadText("Введите имя, фамилию или группу: ");
        var found = _students.Search(query);

        Console.WriteLine();
        if (found.Count == 0)
        {
            Console.WriteLine("Студенты не найдены.");
            return;
        }

        PrintStudents(found);
        Console.WriteLine();
        Console.WriteLine($"Найдено: {found.Count}");
    }

    private static void PrintStudents(IEnumerable<Student> students)
    {
        Console.WriteLine($"{"ID",-5}{"Имя",-14}{"Фамилия",-16}{"Возраст",-9}Группа");
        foreach (var s in students)
            Console.WriteLine($"{s.Id,-5}{s.Name,-14}{s.Surname,-16}{s.Age,-9}{s.Group?.Name}");
    }

    // ---------- преподаватели и группы ----------

    private void ShowTeachers()
    {
        var teachers = _db.Teachers.Include(t => t.Subjects).OrderBy(t => t.Id).ToList();
        if (teachers.Count == 0)
        {
            Console.WriteLine("Преподавателей пока нет.");
            return;
        }

        Console.WriteLine($"{"Имя",-14}{"Фамилия",-16}{"Предмет",-14}Стаж");
        foreach (var t in teachers)
            Console.WriteLine($"{t.Name,-14}{t.Surname,-16}{t.SubjectTitles,-14}{t.Experience}");
    }

    private void ShowGroups()
    {
        var groups = _db.Groups.Include(g => g.Students).OrderBy(g => g.Id).ToList();
        if (groups.Count == 0)
        {
            Console.WriteLine("Групп пока нет.");
            return;
        }

        Console.WriteLine($"{"Группа",-16}{"Курс",-7}Студентов");
        foreach (var g in groups)
            Console.WriteLine($"{g.Name,-16}{g.Course,-7}{g.Students.Count}");
    }

    // ---------- оценки ----------

    private void AddGrade()
    {
        var students = _students.GetAll();
        var subjects = _db.Subjects.OrderBy(s => s.Id).ToList();
        if (students.Count == 0 || subjects.Count == 0)
            throw new ArgumentException("Нужен хотя бы один студент и один предмет.");

        foreach (var s in students) Console.WriteLine($"{s.Id}. {s.FullName} ({s.Group?.Name})");
        var studentId = ReadInt("ID студента: ", 1, int.MaxValue);
        var student = students.FirstOrDefault(s => s.Id == studentId)
            ?? throw new ArgumentException("Студент с таким ID не найден.");

        Console.WriteLine();
        foreach (var s in subjects) Console.WriteLine($"{s.Id}. {s.Title}");
        var subjectId = ReadInt("ID предмета: ", 1, int.MaxValue);
        var subject = subjects.FirstOrDefault(s => s.Id == subjectId)
            ?? throw new ArgumentException("Предмет с таким ID не найден.");

        var value = ReadInt("Оценка (2-5): ", 2, 5);

        _db.Grades.Add(new Grade { StudentId = student.Id, SubjectId = subject.Id, Value = value });
        _db.SaveChanges();

        Console.WriteLine();
        Console.WriteLine("Оценка успешно выставлена!");
    }

    private void ShowGrades()
    {
        var grades = _db.Grades
            .Include(g => g.Student)
            .Include(g => g.Subject)
            .OrderBy(g => g.Id)
            .ToList();

        if (grades.Count == 0)
        {
            Console.WriteLine("Оценок пока нет.");
            return;
        }

        Console.WriteLine($"{"№",-4}{"Студент",-28}{"Оценка",-8}Предмет");
        for (var i = 0; i < grades.Count; i++)
        {
            var g = grades[i];
            Console.WriteLine($"{i + 1,-4}{g.Student?.FullName,-28}{g.Value,-8}{g.Subject?.Title}");
        }

        Console.WriteLine();
        Console.WriteLine($"Средний балл: {grades.Average(g => g.Value):0.00}");
    }

    // ---------- посещаемость ----------

    private void MarkAttendance()
    {
        var students = _students.GetAll();
        if (students.Count == 0)
            throw new ArgumentException("Студентов пока нет.");

        foreach (var s in students) Console.WriteLine($"{s.Id}. {s.FullName} ({s.Group?.Name})");
        var studentId = ReadInt("ID студента: ", 1, int.MaxValue);
        var present = ReadInt("Присутствовал? (1 - да, 0 - нет): ", 0, 1) == 1;

        _attendance.Mark(studentId, present);

        Console.WriteLine();
        Console.WriteLine("Посещаемость отмечена!");
    }

    private void ShowAttendance()
    {
        var records = _attendance.GetAll();
        if (records.Count == 0)
        {
            Console.WriteLine("Отметок посещаемости пока нет.");
            return;
        }

        Console.WriteLine($"{"Дата",-12}{"Студент",-28}Статус");
        foreach (var a in records)
            Console.WriteLine($"{a.Date,-12:dd.MM.yyyy}{a.Student?.FullName,-28}{(a.Present ? "Присутствовал" : "Отсутствовал")}");

        Console.WriteLine();
        Console.WriteLine($"Процент посещаемости: {_attendance.GetPercent():0.0}%");
    }

    // ---------- статистика ----------

    private void ShowStatistics()
    {
        var stats = _reports.GetStatistics();

        Console.WriteLine($"Студентов: {stats.StudentCount}");
        Console.WriteLine($"Преподавателей: {stats.TeacherCount}");
        Console.WriteLine($"Групп: {stats.GroupCount}");
        Console.WriteLine($"Оценок выставлено: {stats.GradeCount}");
        Console.WriteLine($"Средний балл: {stats.AverageGrade:0.00}");
        Console.WriteLine($"Посещаемость: {stats.AttendancePercent:0.0}%");

        if (stats.Groups.Count > 0)
        {
            Console.WriteLine();
            Console.WriteLine("По группам:");
            foreach (var g in stats.Groups)
                Console.WriteLine($"  {g.GroupName} ({g.Course} курс) — студентов: {g.StudentCount}, средний балл: {g.AverageGrade:0.00}");
        }

        Console.WriteLine();
        Console.WriteLine(_reports.GenerateReport());
    }

    // ---------- ввод ----------

    private static string ReadLine() => Console.ReadLine() ?? throw new EndOfStreamException();

    private static string ReadText(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var value = ReadLine().Trim();
            if (value.Length > 0) return value;
            Console.WriteLine("Поле не может быть пустым.");
        }
    }

    private static int ReadInt(string prompt, int min, int max)
    {
        while (true)
        {
            Console.Write(prompt);
            if (int.TryParse(ReadLine().Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value)
                && value >= min && value <= max)
                return value;

            Console.WriteLine(max == int.MaxValue
                ? $"Введите целое число не меньше {min}."
                : $"Введите целое число от {min} до {max}.");
        }
    }

    private static void Pause()
    {
        Console.WriteLine();
        Console.Write("Нажмите Enter, чтобы вернуться в меню...");
        ReadLine();
    }

    private static void Clear()
    {
        try { Console.Clear(); }
        catch (IOException) { }
    }
}
