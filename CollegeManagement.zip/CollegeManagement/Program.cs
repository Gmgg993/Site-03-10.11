using CollegeManagement.Data;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

// Запуск:
//   dotnet run          — консольное меню (по умолчанию)
//   dotnet run -- web   — веб-сайт (ASP.NET Core MVC)

const string DefaultConnection = "Data Source=collegemanagement.db";

var mode = args.FirstOrDefault()?.TrimStart('-').ToLowerInvariant();

if (mode == "web")
    RunWeb(args.Skip(1).ToArray());
else
    RunConsole();

static void AddCollegeServices(IServiceCollection services, string connectionString)
{
    services.AddDbContext<CollegeDbContext>(options => options.UseSqlite(connectionString));
    services.AddScoped<StudentService>();
    services.AddScoped<AttendanceManager>();
    services.AddScoped<ReportManager>();
}

void RunConsole()
{
    var config = new ConfigurationBuilder()
        .SetBasePath(AppContext.BaseDirectory)
        .AddJsonFile("appsettings.json", optional: true)
        .Build();

    var services = new ServiceCollection();
    AddCollegeServices(services, config.GetConnectionString("College") ?? DefaultConnection);
    services.AddScoped<ConsoleMenu>();

    using var provider = services.BuildServiceProvider();
    using var scope = provider.CreateScope();

    scope.ServiceProvider.GetRequiredService<CollegeDbContext>().Initialize();
    scope.ServiceProvider.GetRequiredService<ConsoleMenu>().Run();
}

void RunWeb(string[] webArgs)
{
    var builder = WebApplication.CreateBuilder(webArgs);

    builder.Services.AddControllersWithViews();
    AddCollegeServices(builder.Services, builder.Configuration.GetConnectionString("College") ?? DefaultConnection);

    builder.Services
        .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
        .AddCookie(options =>
        {
            options.LoginPath = "/Home/Login";
            options.Cookie.HttpOnly = true;
            options.Cookie.SameSite = SameSiteMode.Lax;
            options.ExpireTimeSpan = TimeSpan.FromHours(8);
        });
    builder.Services.AddAuthorization();

    var app = builder.Build();

    using (var scope = app.Services.CreateScope())
        scope.ServiceProvider.GetRequiredService<CollegeDbContext>().Initialize();

    app.UseStaticFiles();
    app.UseRouting();
    app.UseAuthentication();
    app.UseAuthorization();

    app.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}");

    app.Run();
}
