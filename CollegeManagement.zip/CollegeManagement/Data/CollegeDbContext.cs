using CollegeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Data;

public class CollegeDbContext : DbContext
{
    public CollegeDbContext(DbContextOptions<CollegeDbContext> options) : base(options) { }

    public DbSet<Student> Students => Set<Student>();
    public DbSet<Teacher> Teachers => Set<Teacher>();
    public DbSet<Group> Groups => Set<Group>();
    public DbSet<Subject> Subjects => Set<Subject>();
    public DbSet<Grade> Grades => Set<Grade>();
    public DbSet<Attendance> Attendances => Set<Attendance>();
    public DbSet<User> Users => Set<User>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Group>().HasIndex(g => g.Name).IsUnique();
        modelBuilder.Entity<User>().HasIndex(u => u.Login).IsUnique();

        // Группу нельзя удалить, пока в ней есть студенты.
        modelBuilder.Entity<Student>()
            .HasOne(s => s.Group)
            .WithMany(g => g.Students)
            .HasForeignKey(s => s.GroupId)
            .OnDelete(DeleteBehavior.Restrict);
    }

    /// <summary>Создаёт базу при первом запуске и заполняет её тестовыми данными.</summary>
    public void Initialize()
    {
        Database.EnsureCreated();

        if (!Groups.Any())
        {
            var web = new Group { Name = "3 веб 1024", Course = 3 };
            var po = new Group { Name = "2 ПО 1024", Course = 2 };
            Groups.AddRange(web, po);

            var aidana = new Student { Name = "Айдана", Surname = "Серикова", Age = 18, Group = web };
            var arman = new Student { Name = "Арман", Surname = "Нурланов", Age = 19, Group = web };
            var dana = new Student { Name = "Дана", Surname = "Ермекова", Age = 18, Group = po };
            Students.AddRange(aidana, arman, dana);

            var php = new Subject { Title = "PHP", Hours = 72 };
            var java = new Subject { Title = "Java", Hours = 72 };
            Teachers.AddRange(
                new Teacher { Name = "Мадина", Surname = "Жумабекова", Age = 35, Experience = 10, Subjects = { php } },
                new Teacher { Name = "Ерлан", Surname = "Садыков", Age = 42, Experience = 16, Subjects = { java } });

            Grades.AddRange(
                new Grade { Student = aidana, Subject = php, Value = 5 },
                new Grade { Student = arman, Subject = java, Value = 4 },
                new Grade { Student = dana, Subject = php, Value = 5 });

            Attendances.AddRange(
                new Attendance { Student = aidana, Present = true },
                new Attendance { Student = arman, Present = false },
                new Attendance { Student = dana, Present = true });
        }

        if (!Users.Any())
        {
            Users.Add(new User { Login = "admin", PasswordHash = User.HashPassword("12345"), Role = "Admin" });
        }

        SaveChanges();
    }
}
