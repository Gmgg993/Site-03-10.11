# CollegeManagement

Управление колледжем на C# (.NET 8, ASP.NET Core MVC + Entity Framework Core + SQLite).

## Запуск

    dotnet run            # консольное меню
    dotnet run -- web     # веб-сайт, адрес покажет Kestrel (в Visual Studio — профиль "Web", http://localhost:5080)

База `collegemanagement.db` создаётся и заполняется тестовыми данными при первом запуске.
Вход в админ-панель сайта: `admin` / `12345`.

## Структура

- `Models/` — Person (базовый класс), Student, Teacher, Group, Subject, Grade, Attendance, User
- `Data/CollegeDbContext.cs` — контекст EF Core, создание БД и тестовые данные
- `Services/` — StudentService, AttendanceManager, ReportManager, ConsoleMenu (консольный интерфейс)
- `Controllers/`, `Views/` — веб-часть (MVC)
- `wwwroot/` — css, js, images
