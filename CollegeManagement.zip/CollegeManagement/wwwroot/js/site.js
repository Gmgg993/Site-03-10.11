// Фокус на первое поле формы, если оно есть.
document.addEventListener('DOMContentLoaded', function () {
    var field = document.querySelector('main form input:not([type=hidden]):not([type=date])');
    if (field && !field.value) field.focus();
});
